<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class time extends Model
{
    //
}
